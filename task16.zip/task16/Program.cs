﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;
using System.Text.Unicode;
using System.Text.Encodings.Web;
using System.IO;

namespace task16
{
    class Program
    {
        static void Main(string[] args)
        {
            int z = 5;
            int[] kod = new int[z];
            string[] name = new string[z];
            double[] many = new double[z];
            for (int i = 0; i < z; i++)
            {
                Console.WriteLine("Введите код товара (целое число)");
                kod[i] = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Введите название товара (строка)");
                name[i] = Convert.ToString(Console.ReadLine());
                Console.WriteLine("Введите цену товара (вещественное число)");
                many[i] = Convert.ToDouble(Console.ReadLine());
            }
            Products products = new Products()
            {
                Kod = kod,
                Name = name,
                Many = many
            };
            JsonSerializerOptions options = new JsonSerializerOptions
            {
                Encoder = JavaScriptEncoder.Create(UnicodeRanges.BasicLatin, UnicodeRanges.Cyrillic)
            };
            string JsonString = JsonSerializer.Serialize(products, options);
            Console.WriteLine(JsonString);
            using (StreamWriter sw = new StreamWriter("D:/_ОБУЧЕНИЕ/МТИ/Задачи/task16/task16/Products.json"))//Ссылка на файл. Файл в архиве в теле задания
            {
                sw.WriteLine(JsonString);
            }
            Console.ReadKey();
        }
    }
    class Products
    {
        public int[] Kod { get; set; }
        public string[] Name { get; set; }
        public double[] Many { get; set; }
    }
}